
def is_even(i):
    if type(i)==int:
      if i%2==0 :
        return "Even"
            else :
        return "Odd"
    else :
        return "Not Allowed"
         

  
    """This function tells us given no is odd/even
    Input any valid number
    output odd/even"""
